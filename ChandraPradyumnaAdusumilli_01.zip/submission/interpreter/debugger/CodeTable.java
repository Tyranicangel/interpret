/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interpreter.debugger;

/**
 *
 * @author Pradyumna
 */
public class CodeTable extends interpreter.CodeTable{
    private static String fileName = "codeList.debug.txt";
}
